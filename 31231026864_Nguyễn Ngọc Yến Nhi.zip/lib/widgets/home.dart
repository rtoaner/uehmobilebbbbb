import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Tin tức',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFFE8955E),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Thông tin mới nhất và kiến thức hữu ích từ UEH',
            style: TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 20),
          _buildNewsCard(
            'TIN TỨC NỔI BẬT',
            'CFVG – UEH chính thức ra mắt chương trình Thạc sĩ Quản trị du lịch liên kết đào tạo cùng Đại học FERRANDI Paris (Pháp)',
          ),
          _buildNewsCard(
            'CUỘC SỐNG UEH',
            'UEH phối hợp Bộ Tài chính tổ chức Hội nghị phổ biến, tập huấn Thông tư số 99/2025/TT-BTC hướng dẫn chế độ kế toán doanh nghiệp.',
          ),
          _buildNewsCard(
            'KHOA HỌC – GÓC NHÌN CHUYÊN GIA',
            '[Research Contribution] Vai trò của công nghệ trong phát triển kinh tế bền vững: Kinh nghiệm từ các quốc gia.',
          ),
        ],
      ),
    );
  }

  Widget _buildNewsCard(String title, String description) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFE8955E))),
            const SizedBox(height: 8),
            Text(description, style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
