import 'package:flutter/material.dart';

class NotificationPage extends StatelessWidget {
  const NotificationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _NotificationItem(
            title:
            'Thư mời tham gia Chương trình Hòa Nhạc Quốc tế Dream Concert Vietnam 2024',
            date: '18:00 - 29/11/2024',
          ),
          _NotificationItem(
            title:
            'Tham dự UEH Career Fair 2024 - Đợt 2 để tìm hiểu cơ hội việc làm và nhận quà hấp dẫn',
            date: '07:00 - 03/11/2024',
          ),
          _NotificationItem(
            title:
            'Cùng UEH Green Citizen tham gia vào dự án UEH Green Campus 2024',
            date: '11:00 - 28/06/2024',
          ),
          _NotificationItem(
            title:
            'Tiếp nhận đăng ký học bổng trao đổi sinh viên quốc tế Đợt 2 Học kỳ đầu 2024',
            date: '18:30 - 17/06/2024',
          ),
        ],
      ),
    );
  }
}

class _NotificationItem extends StatelessWidget {
  final String title;
  final String date;

  const _NotificationItem({required this.title, required this.date});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: ListTile(
        title: Text(title, style: const TextStyle(fontSize: 16)),
        subtitle: Text(date,
            style: const TextStyle(color: Colors.black54, fontSize: 14)),
      ),
    );
  }
}
